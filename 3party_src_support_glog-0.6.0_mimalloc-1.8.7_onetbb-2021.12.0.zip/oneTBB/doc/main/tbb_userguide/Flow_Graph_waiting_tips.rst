.. _Flow_Graph_waiting_tips:

Flow Graph Tips for Waiting for and Destroying a Flow Graph
===========================================================

.. toctree::
   :maxdepth: 4

   ../tbb_userguide/always_use_wait_for_all
   ../tbb_userguide/avoid_dynamic_node_removal
   ../tbb_userguide/destroy_graphs_outside_main_thread