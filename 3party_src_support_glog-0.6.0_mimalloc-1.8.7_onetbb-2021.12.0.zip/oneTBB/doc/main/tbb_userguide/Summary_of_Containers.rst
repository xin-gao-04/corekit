.. _Summary_of_Containers:

Summary of Containers
=====================


The high-level containers in |full_name|
enable common idioms for concurrent access. They are suitable for
scenarios where the alternative would be a serial container with a lock
around it.

