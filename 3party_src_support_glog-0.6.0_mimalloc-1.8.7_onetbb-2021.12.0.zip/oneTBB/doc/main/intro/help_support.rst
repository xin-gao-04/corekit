.. _help_support:

Getting Help and Support
========================


.. container:: section


   .. rubric:: Getting Technical Support
      :class: sectiontitle

   For general information about oneTBB technical support, product
   updates, user forums, FAQs, tips and tricks and other support
   questions, go to `GitHub issues <https://github.com/oneapi-src/oneTBB/issues>`_.
