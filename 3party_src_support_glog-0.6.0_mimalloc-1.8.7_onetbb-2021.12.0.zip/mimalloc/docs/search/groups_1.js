var searchData=
[
  ['basic_20allocation_315',['Basic Allocation',['../group__malloc.html',1,'']]]
];
